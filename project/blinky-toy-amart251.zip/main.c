#include <msp430.h>
#include "libTimer.h"
#include "buzzer.h"

#define SW1 BIT0    /* switch1 is p1.0 */
#define SW2 BIT1    /* switch2 is p1.1 */
#define SW3 BIT2    /* switch3 is p1.2 */
#define SW4 BIT3    /* switch4 is p1.3 */

#define SWITCHES (SW1|SW2|SW3|SW4)   /* all switches on this board */

void main(void) 
{  
  configureClocks();

  P1REN |= SWITCHES;        /* enables resistors for switches */
  P1IE |= SWITCHES;         /* enable interrupts from switches */
  P1OUT |= SWITCHES;        /* pull-ups for switches */
  P1DIR &= ~SWITCHES;       /* set switches' bits for input */

  or_sr(0x18);  // CPU off, GIE on
} 

void
switch_interrupt_handler()
{
  char p1val = P1IN;         /* switches are in P1 */

/* update switch interrupt sense to detect changes from current buttons */
  P1IES |= (p1val & SWITCHES);     /* if switch up, sense down */
  P1IES &= (p1val | ~SWITCHES);    /* if switch down, sense up */

/* play different sound according to the button pressed */
  if (p1val & SW1) {
    buzzer_set_period(1000);	/* 2MHz/1000 = 2kHz */
  } else if (p1val & SW2) {
    buzzer_set_period(2000);	/* 2MHz/2000 = 1kHz */
  } else if (p1val & SW3) {
    buzzer_set_period(3000);	/* 2MHz/3000 ~= 666Hz */
  } else if (p1val & SW4) {
    buzzer_set_period(4000);	/* 2MHz/4000 = 500Hz */
  }
}

/* Switch on P1 */
void
__interrupt_vec(PORT1_VECTOR) Port_1(){
  if (P1IFG & SWITCHES) {            /* did a button cause this interrupt? */
    P1IFG &= ~SWITCHES;              /* clear pending sw interrupts */
    switch_interrupt_handler();      /* single handler for all switches */
  }
}

int main() {
    configureClocks();
 
    buzzer_init();
    buzzer_set_period(1000);	/* start buzzing!!! 2MHz/1000 = 2kHz*/

    or_sr(0x18);          // CPU off, GIE on
}
